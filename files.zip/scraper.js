import axios from "axios";
import linkedIn from "linkedin-jobs-api";
import { SERP_LINKEDIN_QUERIES } from "./config.js";
import fetchWWR from "./scrapers/weworkremotely.js";
import fetchWellfound from "./scrapers/wellfound.js";

const SERP_API_KEY = process.env.SERP_API_KEY;
const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const GOOGLE_CX = process.env.GOOGLE_CX;
const JSEARCH_API_KEY = process.env.JSEARCH_API_KEY;

// ─────────────────────────────────────────────
// REMOTIVE (API pública gratuita — ilimitado)
// ─────────────────────────────────────────────
export async function fetchRemotive() {
  const results = [];
  const categories = ["product", "management"];
  for (const cat of categories) {
    try {
      const res = await axios.get(`https://remotive.com/api/remote-jobs?category=${cat}&limit=50`);
      const jobs = res.data?.jobs || [];
      for (const job of jobs) {
        results.push({
          id: `remotive_${job.id}`,
          source: "Remotive",
          title: job.title,
          company: job.company_name,
          location: job.candidate_required_location || "Remote",
          url: job.url,
          description: job.description?.replace(/<[^>]*>/g, " ").substring(0, 3000),
          salary: job.salary || null,
          publishedAt: job.publication_date,
        });
      }
    } catch (e) {
      console.error("Remotive error:", e.message);
    }
  }
  return results;
}

// ─────────────────────────────────────────────
// HIMALAYAS (API pública gratuita — ilimitado)
// ─────────────────────────────────────────────
export async function fetchHimalayas() {
  const results = [];
  try {
    const res = await axios.get(
      "https://himalayas.app/jobs/api?q=product+manager&limit=50",
      { headers: { Accept: "application/json" } }
    );
    const jobs = res.data?.jobs || [];
    for (const job of jobs) {
      results.push({
        id: `himalayas_${job.slug || job.id}`,
        source: "Himalayas",
        title: job.title,
        company: job.company?.name || job.companyName,
        location: job.locationRestrictions?.join(", ") || "Remote",
        url: `https://himalayas.app/jobs/${job.slug}`,
        description: job.description?.replace(/<[^>]*>/g, " ").substring(0, 3000),
        salary: job.salary || null,
        publishedAt: job.createdAt,
      });
    }
  } catch (e) {
    console.error("Himalayas error:", e.message);
  }
  return results;
}

// ─────────────────────────────────────────────
// LINKEDIN JOBS API (npm — gratuito, sem key)
// github.com/VishwaGauravIn/linkedin-jobs-api
// ─────────────────────────────────────────────
export async function fetchLinkedInDirect() {
  const results = [];
  const queries = [
    { keyword: "Senior Product Manager AI", location: "Europe" },
    { keyword: "Head of Product AI ML", location: "Europe" },
    { keyword: "Technical Product Manager fintech", location: "Europe" },
    { keyword: "Lead Product Manager LLM agents", location: "" },
  ];

  for (const q of queries) {
    try {
      const jobs = await linkedIn.query({
        keyword: q.keyword,
        location: q.location,
        dateSincePosted: "past month",
        jobType: "full time",
        remoteFilter: "remote",
        experienceLevel: "senior",
        limit: "15",
        sortBy: "recent",
      });

      for (const job of jobs) {
        const title = job.position || job.title || "";
        const url = job.jobUrl || "";
        // Pula vagas sem título ou sem URL válida
        if (!title || !url) continue;
        results.push({
          id: `linkedin_${Buffer.from(title + (job.company || "")).toString("base64").substring(0, 20)}`,
          source: "LinkedIn",
          title,
          company: job.company,
          location: job.location || "Remote",
          url,
          description: job.description || "",
          salary: null,
          publishedAt: job.agoTime || null,
        });
      }
    } catch (e) {
      console.error("LinkedIn direct error:", e.message);
    }
    // Delay entre queries para não ser bloqueado
    await new Promise((r) => setTimeout(r, 1500));
  }
  return results;
}

// ─────────────────────────────────────────────
// ENRIQUECIMENTO DE JD via JSearch job-details
// Busca JD completa só para vagas LinkedIn sem descrição
// Gasta 1 request por vaga relevante — aproveitamento máximo
// ─────────────────────────────────────────────
const TARGET_TITLE_KEYWORDS = [
  "product manager", "head of product", "vp of product",
  "director of product", "principal pm", "lead pm", "group pm",
  "technical pm", "ai pm", "product owner",
];

function isRelevantTitle(title = "") {
  const t = title.toLowerCase();
  return TARGET_TITLE_KEYWORDS.some((kw) => t.includes(kw));
}

export async function enrichLinkedInJDs(linkedInJobs) {
  if (!JSEARCH_API_KEY) return linkedInJobs;

  // Só enriquece vagas sem JD que passam no filtro de título
  const toEnrich = linkedInJobs.filter(
    (j) => isRelevantTitle(j.title) && (!j.description || j.description.length < 100) && j.url
  );

  console.log(`  🔍 Enriching ${toEnrich.length} LinkedIn jobs with JSearch job-details...`);

  const enriched = new Map();

  for (const job of toEnrich) {
    try {
      // Extrai job_id do URL do LinkedIn
      // formato: linkedin.com/jobs/view/1234567890
      const jobIdMatch = job.url.match(/\/jobs\/view\/(\d+)/);
      if (!jobIdMatch) continue;

      const res = await axios.get("https://jsearch.p.rapidapi.com/job-details", {
        params: { job_id: `${jobIdMatch[1]}_${encodeURIComponent(job.company || "")}` },
        headers: {
          "X-RapidAPI-Key": JSEARCH_API_KEY,
          "X-RapidAPI-Host": "jsearch.p.rapidapi.com",
        },
        timeout: 8000,
      });

      const details = res.data?.data?.[0];
      if (details?.job_description) {
        enriched.set(job.id, details.job_description.substring(0, 3000));
        console.log(`    ✓ Got JD for "${job.title}" at ${job.company}`);
      }
    } catch (e) {
      // Silencioso — não bloqueia o fluxo
    }
    await new Promise((r) => setTimeout(r, 400));
  }

  // Retorna lista com JDs preenchidas
  return linkedInJobs.map((job) =>
    enriched.has(job.id) ? { ...job, description: enriched.get(job.id) } : job
  );
}

// ─────────────────────────────────────────────
// JSEARCH via RapidAPI (200 req/mês free)
// Agrega LinkedIn, Indeed, Glassdoor e mais
// ─────────────────────────────────────────────
export async function fetchJSearch() {
  if (!JSEARCH_API_KEY) {
    console.warn("JSEARCH_API_KEY not set, skipping JSearch");
    return [];
  }

  const results = [];
  // JSearch retorna JD completa — fonte mais valiosa para scoring preciso
  // 200 req/mês free: 6 queries × 1 = 6 requests por scan
  const queries = [
    "Senior Product Manager AI remote Europe",
    "Head of Product LLM fintech remote",
    "Technical Product Manager AI agents remote EU",
    "Lead Product Manager enterprise B2B remote",
    "Principal Product Manager AI ML remote",
    "Group Product Manager fintech payments remote Europe",
  ];

  for (const query of queries) {
    try {
      const res = await axios.get("https://jsearch.p.rapidapi.com/search", {
        params: {
          query,
          page: "1",
          num_pages: "1",
          date_posted: "month",
          remote_jobs_only: "true",
          employment_types: "FULLTIME,CONTRACTOR",
        },
        headers: {
          "X-RapidAPI-Key": JSEARCH_API_KEY,
          "X-RapidAPI-Host": "jsearch.p.rapidapi.com",
        },
      });

      const jobs = res.data?.data || [];
      for (const job of jobs) {
        results.push({
          id: `jsearch_${job.job_id?.substring(0, 20) || Math.random().toString(36).substring(7)}`,
          source: `JSearch (${job.job_publisher || "Indeed/LinkedIn"})`,
          title: job.job_title,
          company: job.employer_name,
          location: job.job_city ? `${job.job_city}, ${job.job_country}` : job.job_country || "Remote",
          url: job.job_apply_link || job.job_google_link,
          description: job.job_description?.substring(0, 3000) || "",
          salary: job.job_min_salary
            ? `${job.job_salary_currency || "€"}${job.job_min_salary}–${job.job_max_salary} ${job.job_salary_period || ""}`
            : null,
          publishedAt: job.job_posted_at_datetime_utc || null,
        });
      }
    } catch (e) {
      console.error("JSearch error:", e.message);
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return results;
}

// ─────────────────────────────────────────────
// SERPAPI — Google Jobs (100 req/mês free)
// Fallback quando JSearch estiver próximo do limite
// ─────────────────────────────────────────────
export async function fetchViaSerpApi() {
  if (!SERP_API_KEY) {
    console.warn("SERP_API_KEY not set, skipping SerpAPI");
    return [];
  }
  const results = [];
  // Limita a 2 queries para economizar créditos
  const queries = SERP_LINKEDIN_QUERIES.slice(0, 2);
  for (const query of queries) {
    try {
      const res = await axios.get("https://serpapi.com/search", {
        params: {
          engine: "google_jobs",
          q: query,
          hl: "en",
          gl: "us",
          api_key: SERP_API_KEY,
        },
      });
      const jobs = res.data?.jobs_results || [];
      for (const job of jobs) {
        results.push({
          id: `serp_${Buffer.from(`${job.title}_${job.company_name}`).toString("base64").substring(0, 20)}`,
          source: "Google Jobs (SerpAPI)",
          title: job.title,
          company: job.company_name,
          location: job.location || "Remote",
          url: job.related_links?.[0]?.link || job.share_link || "",
          description: job.description?.substring(0, 3000) || "",
          salary: job.detected_extensions?.salary || null,
          publishedAt: job.detected_extensions?.posted_at || null,
        });
      }
    } catch (e) {
      console.error("SerpAPI error:", e.message);
    }
  }
  return results;
}

// ─────────────────────────────────────────────
// GOOGLE CUSTOM SEARCH (100 req/dia free)
// Fallback para Wellfound, WeWorkRemotely, etc.
// ─────────────────────────────────────────────
export async function fetchViaGoogleCustomSearch() {
  if (!GOOGLE_API_KEY || !GOOGLE_CX) {
    console.warn("GOOGLE_API_KEY or GOOGLE_CX not set, skipping Google fallback");
    return [];
  }
  const results = [];
  const queries = [
    "site:wellfound.com Senior Product Manager AI remote Europe",
    "site:weworkremotely.com Product Manager AI ML remote",
    "site:euremotejobs.com Senior PM fintech remote",
  ];
  for (const query of queries) {
    try {
      const res = await axios.get("https://www.googleapis.com/customsearch/v1", {
        params: { key: GOOGLE_API_KEY, cx: GOOGLE_CX, q: query, num: 10 },
      });
      const items = res.data?.items || [];
      for (const item of items) {
        results.push({
          id: `google_${Buffer.from(item.link).toString("base64").substring(0, 20)}`,
          source: "Google Custom Search",
          title: item.title?.replace(/\s*[-|].*$/, "").trim(),
          company: item.pagemap?.organization?.[0]?.name || extractCompany(item.snippet),
          location: "Remote",
          url: item.link,
          description: item.snippet || "",
          salary: null,
          publishedAt: null,
        });
      }
    } catch (e) {
      console.error("Google Custom Search error:", e.message);
    }
  }
  return results;
}

function extractCompany(snippet = "") {
  const match = snippet.match(/at ([A-Z][a-zA-Z\s]+?)[\s,.|]/);
  return match?.[1]?.trim() || "Unknown";
}

// ─────────────────────────────────────────────
// AGREGADOR PRINCIPAL
// Prioridade: LinkedIn Direct > JSearch > SerpAPI > Google
// ─────────────────────────────────────────────
export async function fetchAllJobs() {
  console.log("🔍 Fetching jobs from all sources...");

  const [remotive, himalayas, linkedInDirect, jsearch, serp, google, wwr, wellfound] =
    await Promise.allSettled([
      fetchRemotive(),
      fetchHimalayas(),
      fetchLinkedInDirect(),
      fetchJSearch(),
      fetchViaSerpApi(),
      fetchViaGoogleCustomSearch(),
      fetchWWR(),
      fetchWellfound(),
    ]);

  // Enriquece vagas do LinkedIn com JD completa via JSearch job-details
  // Só para vagas com título relevante e sem JD — gasta requests de forma inteligente
  const linkedInJobs = linkedInDirect.status === "fulfilled" ? linkedInDirect.value : [];
  const linkedInEnriched = await enrichLinkedInJDs(linkedInJobs);

  const sourceSummary = {
    Remotive: remotive.status === "fulfilled" ? remotive.value.length : 0,
    Himalayas: himalayas.status === "fulfilled" ? himalayas.value.length : 0,
    LinkedIn: linkedInEnriched.length,
    "LinkedIn w/ JD": linkedInEnriched.filter((j) => j.description?.length > 100).length,
    JSearch: jsearch.status === "fulfilled" ? jsearch.value.length : 0,
    SerpAPI: serp.status === "fulfilled" ? serp.value.length : 0,
    Google: google.status === "fulfilled" ? google.value.length : 0,
    WeWorkRemotely: wwr.status === "fulfilled" ? wwr.value.length : 0,
    Wellfound: wellfound.status === "fulfilled" ? wellfound.value.length : 0,
  };
  console.log("📊 Jobs per source:", sourceSummary);

  const all = [
    ...(remotive.status === "fulfilled" ? remotive.value : []),
    ...(himalayas.status === "fulfilled" ? himalayas.value : []),
    ...linkedInEnriched,
    ...(jsearch.status === "fulfilled" ? jsearch.value : []),
    ...(serp.status === "fulfilled" ? serp.value : []),
    ...(google.status === "fulfilled" ? google.value : []),
    ...(wwr.status === "fulfilled" ? wwr.value : []),
    ...(wellfound.status === "fulfilled" ? wellfound.value : []),
  ];

  // Deduplicar por título + empresa (case-insensitive)
  const seen = new Set();
  const unique = all.filter((job) => {
    const key = `${job.title?.toLowerCase().trim()}_${job.company?.toLowerCase().trim()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  console.log(`✅ Total unique jobs fetched: ${unique.length}`);
  return unique;
}
